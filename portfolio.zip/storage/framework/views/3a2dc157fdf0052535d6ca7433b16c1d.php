<?php

    $footer_info = \App\Models\FooterInfo::first();
    $footer_icons = \App\Models\FooterSocialLink::all();
    $footer_useful_links = \App\Models\FooterUsefulLink::all();
    $footer_contact = \App\Models\FooterContactInfo::first();
    $footer_help_links = \App\Models\FooterHelpLink::all();

?>

    <!-- Footer-Area-Start -->
<footer class="footer-area">
    <div class="container">
        <div class="row footer-widgets">
            <div class="col-md-12 col-lg-3 widget">
                <div class="text-box">
                    <figure class="footer-logo">
                        <img src="<?php echo e(asset($general_setting->footer_logo)); ?>" alt="">
                    </figure>
                    <p><?php echo e($footer_info->info); ?></p>
                    <ul class="d-flex flex-wrap">
                        <?php $__currentLoopData = $footer_icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($icon->url); ?>" target="_blank"><i class="<?php echo e($icon->icon); ?>"></i></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-lg-2 offset-lg-1 widget">
                <h3 class="widget-title">Useful Link</h3>
                <ul class="nav-menu">
                    <?php $__currentLoopData = $footer_useful_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $useful_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($useful_link->url); ?>"><?php echo e($useful_link->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <div class="col-md-4 col-lg-3 widget">
                <h3 class="widget-title">Contact Info</h3>
                <ul>
                    <li><?php echo e($footer_contact->address); ?></li>
                    <li><a href="#"><?php echo e($footer_contact->phone); ?></a></li>
                    <li><a href="#"><?php echo e($footer_contact->email); ?></a></li>
                </ul>
            </div>
            <div class="col-md-4 col-lg-3 widget">
                <h3 class="widget-title">Help</h3>
                <ul class="nav-menu">
                    <?php $__currentLoopData = $footer_help_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $help_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($help_link->url); ?>"><?php echo e($help_link->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="copyright">
                        <p><?php echo e($footer_info->copyright); ?></p>
                        <p><?php echo e($footer_info->powered_by); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer-Area-End -->
<?php /**PATH C:\laragon\www\portfolio\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>